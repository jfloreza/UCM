CSE-170 GLUTAPP
---------------

This is a demo project to start implementing OpenGL applications
using GLUT. Whenever you start a new project, rename the folder 
from glutapp to the name of your new project and edit/add to the 
source files to build your application.

Linux:
 - Type make to compile the application
 - The makefile will compile all .cpp files in the folder
 - Edit the makefile to change the name of the executable

Windows:
 - Use the visual studio 9 project in the visualc9 folder
 - Make sure visualc 2008 is installed 
 - To open the project just double click the .sln file

Note:
 - the provided glut library is only used in Windows



