#include <iostream>
#include <list>
#include <iterator>

using namespace std;

void print(int * array);
void search(int * array);
void hashdel(int * array);

void print(int * array)
{

}

void search(int * array)
{

}

void hashdel(int * array)
{

}

int main()
{
	int i = 0;
	int temp = 0;
	int size = 0;
	int * array;
	while(1)
	{	
		cin >> temp;
		switch(temp) {
			
			case -1:
				print(array, i);
				break;
			case -2:
				search(array, i);
				break;
			case -3:
				hashdel(array, i);
				return 0;
			default:
				array = (int *)malloc(i * sizeof(int));
				array[i] = temp;
				i++;
				break;
				
			}
	}
}
