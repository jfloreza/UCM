#include <stdio.h>
#include <stdlib.h>

int bin(int * array, int size, int search)
{
	int l = 0;
	int r = size;
	int m;
	
	while (l <= r)
	{
		m = (r + l) / 2;
		if(array[m] == search)return m;
		else if (array[m] > search)
		{
			r = m - 1;
		}
		else l = m + 1;
	}
	return -1;
}

int main(int argc, char* argv[])
{
	int size = -1;
	int val;
	int search;
	int i = 0;
	int * array;
	while(1)
	{
		scanf("%i", &size);
		if(size == 0)break;
		
		scanf("%i", &search);
		array = (int *)malloc(size * sizeof(int));
		
		for(i = 0; i < size; i++)
		{
			scanf("%i", &array[i]);
		}
	val = bin(array, size, search);
	printf("%i\n", val);
	free(array);
	}

}
