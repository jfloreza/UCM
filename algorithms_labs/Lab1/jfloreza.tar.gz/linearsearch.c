#include <stdio.h>
#include <stdlib.h>

int lin(int * array, int size, int search)
{
	int i = 0;
	for(i = 0; i < size; i++)
	{
		if(array[i] == search)return i;
	}
	
	return -1;
	
}

int main(int argc, char* argv[])
{
	int size = -1;
	int val;
	int search;
	int i = 0;
	int * array;
	while(1)
	{
		scanf("%i", &size);
		if(size == 0)break;
		
		scanf("%i", &search);
		array = (int *)malloc(size * sizeof(int));
		
		for(i = 0; i < size; i++)
		{
			scanf("%i", &array[i]);
		}
	val = lin(array, size, search);
	printf("%i\n", val);
	free(array);
	}

}
